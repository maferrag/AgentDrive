Balanced selection of MCQ JSONs
Source:  /content/drive/MyDrive/DriveBench/mcq_jsons_MCQ
Target:  /content/drive/MyDrive/DriveBench/mcq_jsons_MCQ_200_balanced
Styles:  physics, policy, hybrid, scenario, comparative
Per style target: 40
Total target: 200
Allow backfill: False
Shuffle seed: 42
Timestamp: 2025-10-09T09:39:06
